# TickitEasy
TickitEasy：SpringBoot 開發版本  

EEIT87 第三組 專題
<br>

## 文件

https://eeit87t3.github.io/TickitEasySpringBoot/
<br>

## 測試

1. 資料庫連線  
http://localhost:8080/TickitEasy/test/connection  

2. 後台模板  
http://localhost:8080/TickitEasy/test/admin-template  

3. 圖片讀取  
http://localhost:8080/TickitEasy/images/test/logo.png